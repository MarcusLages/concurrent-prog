defmodule Arithmetic.Worker do
  use GenServer

  def start() do
    GenServer.start(__MODULE__, nil)
  end

  @impl true
  def init(arg) do {:ok, arg} end

  @impl true
  def handle_cast({:square, x, from}, state) do
    Process.sleep(4000)
    send(from, {self(), x * x})
    {:noreply, state}
  end

  @impl true
  def handle_cast({:sqrt, x, from}, state) do
    Process.sleep(4000)
    res = if x < 0,
    do:
      {self(), :error},
    else:
      {self(), :math.sqrt(x)}
    send(from, res)
    {:noreply, state}
  end

  def square(pid, x) do
    GenServer.cast(pid, {:square, x, self()})
  end

  def sqrt(pid, x) do
    GenServer.cast(pid, {:sqrt, x, self()})
  end

end

defmodule Arithmetic.Server do
  use GenServer

  def start(workers \\ 1) do
    if workers < 1, do: :error,
    else: GenServer.start(__MODULE__, start_workers(workers), name: __MODULE__)
  end

  defp start_workers(0, acc) do acc end
  defp start_workers(n, acc) do
    {_, worker} = Arithmetic.Worker.start()
    start_workers(n - 1, [worker | acc])
  end
  defp start_workers(n) do
    start_workers(n, [])
  end

  @impl true
  def init(arg) do {:ok, arg} end

  @impl true
  def handle_call(:get_worker, _from, [h | t]) do
    {:reply, h, t ++ [h]}
  end

  def square(x) do
    worker = GenServer.call(__MODULE__, :get_worker)
    Arithmetic.Worker.square(worker, x)
  end

  def sqrt(x) do
    worker = GenServer.call(__MODULE__, :get_worker)
    Arithmetic.Worker.sqrt(worker, x)
  end

end

# alias Arithmetic.Worker
# alias Arithmetic.Server
